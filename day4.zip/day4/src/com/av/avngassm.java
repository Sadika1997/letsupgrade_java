package com.av;

public class avngassm {
    public static void main(String[] args) {

        avng[] avgs = new avng[5];

        System.out.println("Avengers Initiative:");
        for (int i = 0; i < avgs.length; i++) {
            avgs[i] = new avng();
            avgs[i].getDetails();
            System.out.println();
        }
        System.out.println("Avengers Assemble...");
        for (int i = 0; i < avgs.length; i++) {
            System.out.println();
            avgs[i].displayDetails();
            System.out.println();
        }

    }
}
