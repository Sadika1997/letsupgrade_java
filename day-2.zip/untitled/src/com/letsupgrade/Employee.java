package com.letsupgrade;

public class Employee {

        String name, city;
        int age;

        public void displayDetails(){

            System.out.println("\nThe name is " + name);
            System.out.println("The age is " + age);
            System.out.println("The city is " + city);

        }

    }

