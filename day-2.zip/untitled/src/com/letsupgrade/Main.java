package com.letsupgrade;

public class Main {

        public static void main(String[] args) {

            Employee e1 =  new Employee();
            Employee e2 =  new Employee();

            e1.name = "Sadika";
            e1.age = 21;
            e1.city = "Banglore";

            e2.name = "Rumaan";
            e2.age = 22;
            e2.city = "Pune";


            e1.displayDetails();
            e2.displayDetails();

        }
    }

